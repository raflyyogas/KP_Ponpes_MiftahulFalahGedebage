
<?php $__env->startSection('data'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs ======= -->
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="breadcrumb-hero">
                <div class="container">
                    <div class="breadcrumb-hero">
                        <h2>Pendidikan</h2>
                        <p>Est dolorum ut non facere possimus quibusdam eligendi voluptatem. Quia id aut similique quia
                            voluptas sit quaerat debitis. Rerum omnis ipsam aperiam consequatur laboriosam nemo harum
                            praesentium. </p>
                    </div>
                </div>
            </div>
        </section><!-- End Breadcrumbs -->

        <div class="container mt-5 mb-5 shadow p-3 bg-body rounded">
            <div class="row">
                <div class="col ">
                    <div class="text-center mb-3 text-decoration-underline">Pendidikan Formal</div>
                    <ol>
                        <li>MI Miftahul Falah</li>
                        <img src="<?php echo e(asset('images\profilsekolah\logo.jpg')); ?>"><br>
                        <div class="text-grey mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla
                            distinctio corrupti asperiores vero
                            animi neque pariatur illo velit molestiae in!</div>
                        <li>MTs Miftahul Falah</li>
                        <img src="<?php echo e(asset('images\profilsekolah\logo.jpg')); ?>"><br>
                        <div class="text-grey mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla
                            distinctio corrupti asperiores vero
                            animi neque pariatur illo velit molestiae in!</div>
                        <li>MA Miftahul Falah</li>
                        <img src="<?php echo e(asset('images\profilsekolah\logo.jpg')); ?>"><br>
                        <div class="text-grey mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla
                            distinctio corrupti asperiores vero
                            animi neque pariatur illo velit molestiae in!</div>
                    </ol>
                </div>
                <div class="col ">
                    <div class="text-center mb-3 text-decoration-underline">Pendidikan Non formal</div>
                    <ol>
                        <li>Tahfidzul Qur’an</li>
                        <img src="<?php echo e(asset('images\profilsekolah\logo.jpg')); ?>"><br>
                        <div class="text-grey mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla
                            distinctio corrupti asperiores vero
                            animi neque pariatur illo velit molestiae in!</div>
                        <li>Madrasah Diniyah</li>
                        <img src="<?php echo e(asset('images\profilsekolah\logo.jpg')); ?>"><br>
                        <div class="text-grey mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla
                            distinctio corrupti asperiores vero
                            animi neque pariatur illo velit molestiae in!</div>
                        <li>Majelis Taklim</li>
                        <img src="<?php echo e(asset('images\profilsekolah\logo.jpg')); ?>"><br>
                        <div class="text-grey mb-3">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla
                            distinctio corrupti asperiores vero
                            animi neque pariatur illo velit molestiae in!</div>
                    </ol>
                </div>
            </div>
        </div>

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KP_Ponpes_MiftahulFalahGedebage\resources\views/pendidikan.blade.php ENDPATH**/ ?>