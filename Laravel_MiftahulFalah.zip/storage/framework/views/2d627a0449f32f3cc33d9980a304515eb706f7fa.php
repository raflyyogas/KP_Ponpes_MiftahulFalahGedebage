
<?php $__env->startSection('data'); ?>
    <main id="main">
        <!-- ======= Breadcrumbs ======= -->
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="breadcrumb-hero">
                <div class="container">
                    <div class="breadcrumb-hero">
                        <h2>Galeri Video</h2>
                        <p>Galeri video ini merupakan kumpulan video dokumentasi mengenai kegiatan yang dilaukan di
                            Pesantren
                            Miftahul Falah. </p>
                    </div>
                </div>
            </div>
        </section><!-- End Breadcrumbs -->

        <!-- ======= Team Section ======= -->

        <section class="team" id="team">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-6">
                            <p class="text-center"><iframe width="560" height="340"
                                    src="https://www.youtube.com/embed/<?php echo e(substr($data->link, -11)); ?>"
                                    title="Youtube Video Player" frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
                                    allowfullscreen>
                                </iframe></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup KP\KP_Ponpes_MiftahulFalahGedebage\resources\views/video.blade.php ENDPATH**/ ?>