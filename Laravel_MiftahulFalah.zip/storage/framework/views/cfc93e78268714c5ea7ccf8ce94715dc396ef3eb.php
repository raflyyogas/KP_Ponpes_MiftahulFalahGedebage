
<?php $__env->startSection('data'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs ======= -->
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">
                <ol>
                    <li><a class="text-primary" href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li><a class="text-primary" href="<?php echo e(route('blog')); ?>">Artikel</a></li>
                    <li><?php echo e($item->judul); ?></li>
                </ol>
            </div>
        </section><!-- End Breadcrumbs -->

        <!-- ======= Blog Single Section ======= -->
        <section id="blog" class="blog">
            <div class="container" data-aos="fade-up">

                <div class="row">

                    <div class="col-lg-8 entries">

                        <article class="entry entry-single">

                            <div class="entry-img">
                                <img src="<?php echo e(asset('upload/thumbnail/' . $item->foto)); ?>" alt="" class="img-fluid"
                                    style="min-width:100px">
                            </div>

                            <h2 class="entry-title">
                                <a href="#"><?php echo e($item->judul); ?></a>
                            </h2>

                            <div class="entry-meta">
                                <ul>
                                    <li class="d-flex align-items-center"><i
                                            class="bi bi-person"></i><?php echo e($item->penulis); ?></li>
                                    <li class="d-flex align-items-center"><i
                                            class="bi bi-clock"></i><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('j F Y')); ?>

                                    </li>
                                </ul>
                            </div>

                            <div class="entry-content">
                                <?php echo $item->deskripsi; ?>


                            </div>

                        </article><!-- End blog entry -->

                    </div><!-- End blog entries list -->

                    <div class="col-lg-4">

                        <div class="sidebar">

                            <h3 class="sidebar-title">Search</h3>
                            <div class="sidebar-item search-form">
                                <form action="/blog">
                                    <input type="text" placeholder="Cari artikel" name="search"
                                        value="<?php echo e(request('search')); ?>">
                                    <button type="submit"><i class="bi bi-search"></i></button>
                                </form>
                            </div><!-- End sidebar search formn-->

                            <h3 class="sidebar-title">Recent Posts</h3>
                            <div class="sidebar-item recent-posts">

                                <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="post-item clearfix">

                                        <img src="<?php echo e(asset('upload/thumbnail/' . $data->foto)); ?>"
                                            alt="<?php echo e($data->judul); ?>">
                                        <h4><a
                                                href="<?php echo e(route('slug', ['slug' => $data->slug])); ?>"><?php echo e($data->judul); ?></a>
                                        </h4>
                                        <time
                                            datetime="2020-01-01"><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('j F Y')); ?></time>
                                    </div>
                                    <?php $i++; ?>
                                    <?php if($i > 4): ?>
                                    <?php break; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!-- End sidebar recent posts-->

                    </div><!-- End blog sidebar -->

                </div>

            </div>
    </section><!-- End Blog Single Section -->

</main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup KP\KP_Ponpes_MiftahulFalahGedebage\resources\views/artikel.blade.php ENDPATH**/ ?>