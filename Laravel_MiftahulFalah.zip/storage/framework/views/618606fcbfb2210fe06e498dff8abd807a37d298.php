
<?php $__env->startSection('main'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Artikel</h1>
    <p class="mb-4">Jika tidak mengerti dalam pengisian artikel. Silahkan download artikel ini</a>.</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Artikel</h6>
        </div>
        <div class="card-body">

            <?php if(session('success')): ?>
                
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID Artikel</th>
                            <th>Gambar Artikel</th>
                            <th>Judul artikel</th>
                            <th>Deskripsi</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="max-width:20px"><?php echo e($item->id); ?></td>
                                <td style="max-width:200px">
                                    <img src="<?php echo e(asset('upload/thumbnail/' . $item->foto)); ?>" alt=""
                                        class="rounded-circle-profile" width="70%">
                                </td>
                                <td><?php echo e($item->judul); ?></td>
                                <td style="max-width:400px"> <?php echo Str::limit($item->deskripsi, 250); ?></td>
                                <td>
                                    <a href="<?php echo e(route('editartikel', ['id' => $item->id])); ?>"
                                        class="btn btn-info btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-pencil-alt"></i>
                                        </span>
                                    </a>
                                    <a href="<?php echo e(route('delartikel', ['id' => $item->id])); ?>"
                                        class="btn btn-danger btn-icon-split">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-trash"></i>
                                        </span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup KP\KP_Ponpes_MiftahulFalahGedebage\resources\views/tampilan/artikel.blade.php ENDPATH**/ ?>