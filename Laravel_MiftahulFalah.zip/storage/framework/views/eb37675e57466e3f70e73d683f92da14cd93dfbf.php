
<?php $__env->startSection('main'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Informasi kontak kami</h1>
    <p class="mb-4"></p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Informasi kontak kami</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <?php if(session('success')): ?>
                        
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <div type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></div>
                        </div>
                    <?php endif; ?>
                    <?php if($kontak->count() > 0): ?>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Penanya</th>
                                <th>No HP</th>
                                <th>Subjek</th>
                                <th>Pesan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->nohp); ?></td>
                                    <td><?php echo e($item->subject); ?></td>
                                    <td><?php echo e($item->message); ?></td>
                                    <th><a href="<?php echo e(route('delkon', ['id' => $item->id])); ?>"
                                            class="btn btn-danger btn-icon-split">
                                            <span class="icon text-white-50">
                                                <i class="fas fa-trash"></i>
                                            </span>
                                        </a></th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    <?php else: ?>
                        Tidak ada pesan
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup KP\KP_Ponpes_MiftahulFalahGedebage\resources\views/tampilan/contact.blade.php ENDPATH**/ ?>