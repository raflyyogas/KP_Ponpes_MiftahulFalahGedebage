
<?php $__env->startSection('data'); ?>
    <main id="main">

        <!-- ======= Breadcrumbs ======= -->
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="breadcrumb-hero">
                <div class="container">
                    <div class="breadcrumb-hero">
                        <h2>Galeri Foto</h2>
                        <p>Galeri foto ini merupakan kumpulan foto dokumentasi mengenai kegiatan yang dilaukan di Pesantren
                            Miftahul Falah</p>
                    </div>
                </div>
            </div>
        </section><!-- End Breadcrumbs -->

        <!-- ======= Portfolio Section ======= -->
        <section id="portfolio" class="portfolio">
            <div class="container">

                

                <div class="row portfolio-container" data-aos="fade-up">

                    <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 portfolio-item filter-app">
                            <div class="portfolio-wrap">
                                <img src="<?php echo e(asset('upload/gallery-foto/' . $data->foto)); ?>" class="img-fluid" alt="">
                                <div class="portfolio-info">
                                    <h4><?php echo e($data->judul); ?></h4>
                                    <p><?php echo e(Str::limit($data->deskripsi, 10)); ?></p>
                                    <div class="portfolio-links">
                                        <a href="<?php echo e(asset('upload/gallery-foto/' . $data->foto)); ?>"
                                            data-gallery="portfolioGallery" class="portfolio-lightbox"
                                            title="<?php echo e($data->deskripsi); ?>"><i class="bx bx-plus"></i></a>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </section><!-- End Portfolio Section -->

    </main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backup KP\KP_Ponpes_MiftahulFalahGedebage\resources\views/foto.blade.php ENDPATH**/ ?>